cd /home/msp/pd/extra
tar czf /tmp/z.tgz \
   pd~/pd~.c pd~/pd~-help.pd pd~/pd~-subprocess.pd \
   sigmund~/sigmund~.c sigmund~/sigmund~-help.pd \
   bonk~/bonk~.c bonk~/bonk~-help.pd

ls -l /tmp/z.tgz


